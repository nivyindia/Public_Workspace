# Module 7.1 — Deliverability / Domain Health Monitor

## Kya karta hai
Daily Postal ke send-stats check karta hai, bounce/complaint rate calculate karta hai, threshold cross hone par Odoo Discuss alert deta hai.

## ⚠️ Assumptions
- **Thresholds:** bounce rate >5%, complaint rate >0.1% — industry-standard defaults hain, KB mein specific number nahi tha.
- **Postal API endpoint path** version-dependent hai — deploy karte waqt confirm karna, exact path badal sakta hai.

## Known Limitations
- SPF/DKIM/DMARC record health khud check nahi karta (sirf send-stats) — agar DNS-record-level monitoring bhi chahiye, wo alag node (external DNS-check API) hoga.
