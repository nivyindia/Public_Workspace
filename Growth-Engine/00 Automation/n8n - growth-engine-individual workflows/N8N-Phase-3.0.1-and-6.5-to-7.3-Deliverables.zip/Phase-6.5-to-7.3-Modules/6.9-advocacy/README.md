# Module 6.9 — Advocacy Candidate Report

## Kya karta hai
Har mahine `nps_responses` aur `referrals` data se "advocate candidates" (sustained satisfaction) surface karta hai, Odoo Discuss par curated list post karta hai. **Report-only** — koi outreach automatically nahi jaata, KB khud kehta hai relationship-cultivation hamesha human-led rahega.

## ⚠️ Business assumption
Threshold assume kiya: **6 mahine mein 2+ NPS score 9-10 HO, YA 2+ successfully-converted referrals.** KB "sustained satisfaction" bolta hai par exact number nahi deta. Batao to adjust kar dunga.

## Known Limitations
- No dedicated `advocates` table — candidates har mahine fresh query se nikalte hain, `advocate_flag` column already assumed hai but koi node isko actually set nahi karta abhi (human review ke baad manually set karna hoga, ya batao to auto-set kar dunga review-approval ke baad).
