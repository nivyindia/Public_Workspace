# Module 6.8 — Referral Link Generation + Reward Trigger

## Kya karta hai
Promoter-flagged clients ke liye unique referral code/link generate karta hai, referral-ask email bhejta hai, aur jab koi referred lead `Won`/`Paid` status tak pahunche to Odoo Discuss par payout-due alert deta hai.

## ⚠️ Sabse critical assumption — payout amount deliberately auto-calculate NAHI kiya
KB (Stage 53) explicitly kehta hai commission/incentive rate **"deliberate business decision, documented consistently, not negotiated ad hoc"** — koi number kahi nahi diya. Isliye is workflow ka reward-alert node **sirf "payout due hai" bolta hai, amount calculate nahi karta.** Jab tumhara commission % (ya flat amount) decide ho jaye, ek chhota patch node add kar dunga jo amount bhi calculate kare.

## Integration gap (flag kar raha hoon, fix nahi kiya)
`?ref=<code>` se aane wale referred leads ko track karne ke liye Module 1.3 (website lead capture) ya 1.4 (form qualification) mein ek chhota patch chahiye — query param capture karke `clients_master.referral_code_used` mein save karna. Ye is module ka scope nahi tha (wo Phase 3-era modules hain), par is workflow ke reward-trigger ka poora working isi field par depend karta hai. Batao to wahan bhi patch kar deta hoon.

## Naya DB table + column chahiye
```sql
CREATE TABLE IF NOT EXISTS referrals (
  id SERIAL PRIMARY KEY,
  referrer_client_id INTEGER REFERENCES clients_master(id),
  referral_code TEXT UNIQUE,
  status TEXT DEFAULT 'link_generated',
  converted_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS referral_code_used TEXT;
```

## Known Limitations
- Reward amount not calculated (see above — by design, not a bug).
- `referral_code_used` capture not yet wired into Module 1.3/1.4 (see integration gap above).
