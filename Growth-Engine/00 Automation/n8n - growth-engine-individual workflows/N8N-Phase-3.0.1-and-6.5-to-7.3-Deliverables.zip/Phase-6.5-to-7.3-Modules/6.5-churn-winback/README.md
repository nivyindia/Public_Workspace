# Module 6.5 — Churn Win-back + Escalation

## Kya karta hai
`clients_master.status = 'Churn Risk'` (Module 2.9 ka existing flag) wale clients ko ek 3-touch win-back sequence deta hai — Day 0 email, Day 7 WhatsApp, Day 14 email — aur agar 21 din tak koi response nahi to founder ko direct escalate karta hai, bina koi aur client-facing message bheje.

## ⚠️ Business assumptions (Nivy sign-off chahiye)
- **Cadence:** 7-din gap har touch ke beech, 3 touches ke baad escalation — ye KB mein defined nahi tha (KB sirf pre-churn "save-a-client call" cover karta hai, post-churn win-back nahi). SQL query ke intervals badal ke actual cadence set kar sakte ho.
- **Escalation trigger:** koi response track nahi ho raha explicitly (reply-tracking Module 4.3 se link nahi kiya abhi) — sirf "status abhi bhi Churn Risk hai" ke base par escalate karta hai. Agar client respond kare, uska status change karna manual/Module-4.3-linked hona chahiye taaki sequence ruk jaye.

## Naye DB fields chahiye
```sql
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS winback_step INTEGER DEFAULT 0;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_winback_sent_at TIMESTAMP;
```

## Import
Standard n8n import → `workflow.json` → set Postgres/Odoo credentials → set env vars (`OUTREACH_FROM_EMAIL`, `WAHA_URL`, `WAHA_API_KEY`, `WAHA_SESSION`, `ODOO_*`) → activate.

## Known Limitations
- No reply-suppression yet (see assumption above) — client jawab de bhi de, sequence chalta rahega jab tak status manually change na ho.
- Founder escalation sirf Odoo Discuss alert hai, koi task/reminder auto-create nahi hota.
