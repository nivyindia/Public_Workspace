# Module 6.7 — Case Study / Testimonial Auto-Request

## Kya karta hai
Promoter-flagged clients (Module 6.6 se) ko testimonial-ask email bhejta hai; jab client reply kare, Ollama unke raw words ko polished quote mein format karta hai, `case_studies` table mein `pending_client_approval` status ke saath store karta hai, aur Odoo Discuss par human-review alert deta hai. **Koi auto-publish nahi hai** — client ka final sign-off zaroori hai (KB ki requirement).

## ⚠️ Business assumptions
- **Sirf NPS-promoter trigger wired hai.** KB Stage 52 ek dusra trigger bhi mention karta hai — "milestone-completion event" (Odoo project stage = done). Wo is version mein nahi hai, kyunki Odoo project-stage-completion webhook abhi kahi wired nahi hai. Agar chahiye to add kar sakta hoon.
- **Reply-capture** existing Module 2.1 ke Postal inbound-reply pattern ko reuse karta hai — agar us pattern mein change ho, isko bhi update karna hoga.

## Naya DB table chahiye
```sql
CREATE TABLE IF NOT EXISTS case_studies (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  raw_reply TEXT,
  polished_quote TEXT,
  status TEXT DEFAULT 'pending_client_approval',
  created_at TIMESTAMP DEFAULT now()
);
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS testimonial_ask_sent_at TIMESTAMP;
```

## Known Limitations
- No client-approval webhook yet — approval is tracked manually (update `case_studies.status` by hand once client confirms). Could add a signed-link approval flow later, same HMAC pattern as Module 3.0.1, if needed.
- Milestone-completion trigger not wired (see assumption above).
