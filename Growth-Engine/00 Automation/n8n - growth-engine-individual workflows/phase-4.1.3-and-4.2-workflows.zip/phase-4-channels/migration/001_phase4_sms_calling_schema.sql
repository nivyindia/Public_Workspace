-- Phase 4.1.3 (SMS Re-engagement) + 4.2 (Cold Calling) — schema additions
-- Convention: ALTER TABLE ... ADD COLUMN IF NOT EXISTS (matches every existing module, per tracker §0.4 rule 7)
-- Run this once against the `growthengine` Postgres DB before importing/activating these 3 workflows.

-- ── Consent / suppression columns (tracker §16.4 — needed by 4.1.3 to scope to consented leads only) ──
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS sms_opt_out BOOLEAN DEFAULT false;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS call_dnc BOOLEAN DEFAULT false;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS active_sequence_suppressed BOOLEAN DEFAULT false;

-- ── 4.1.3 SMS Re-engagement ──
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_sms_sent_at TIMESTAMP;

-- ── 4.2.1 / 4.2.2 Cold Calling ──
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_call_at TIMESTAMP;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS call_attempts INTEGER DEFAULT 0;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_call_outcome TEXT;

-- ── Shared idempotency table (tracker §16.2 standard — reused by 4.2.2's Call Outcome Webhook) ──
-- If Phase 3.0 patches (3.0.1–3.0.3) are already applied against this DB, this table may already
-- exist — IF NOT EXISTS makes this safe to run either way.
CREATE TABLE IF NOT EXISTS webhook_events (
  event_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  received_at TIMESTAMP DEFAULT now(),
  processed_at TIMESTAMP,
  status TEXT DEFAULT 'received',
  attempts INTEGER DEFAULT 0,
  last_error TEXT,
  raw_payload JSONB
);
