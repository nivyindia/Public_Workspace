# S4.3 — Migrate 2.4 Proposal Generation to the Hub (this batch)

Scope: only S4.3 from the plan. S4.1, S4.2, S4.4–S4.8 (the other 8 Phase-2
modules) are still open.

## What changed in `2.4-proposal-generation/workflow.json`

1. **Trigger swapped.** `From Module 1.5 (status = Booked)` (a bare
   `executeWorkflowTrigger` with no declared inputs) → `From Hub-Dispatcher
   (lead.booked)`, with the same declared input shape as Hub-Intake's own
   trigger (`event_type`, `client_id`, `odoo_lead_id`, `source_module`,
   `payload`). This matches what Hub-Dispatcher's existing `Execute Workflow
   - 2.4 Proposal Generation` node already passes through — that node was
   built in S2 (ahead of the receiving end), so this was the missing half.
   1.5 no longer calls 2.4 directly; it hasn't since S3.3 removed 1.5's
   direct `Execute Workflow` nodes. Until this batch, 2.4 was effectively
   unreachable — that gap is now closed.
2. **New `Report to Hub` node**, fired after `Postgres - Mark Proposal
   Sent` (in parallel with the existing `Odoo Discuss - Proposal Sent
   Alert`, not replacing it) → `event_type: proposal.sent`, `source_module:
   "2.4"`, `client_id` pulled from `Fetch Lead Detail`'s row, `payload` with
   `proposal_url` / `recommended_tier` / `recommended_price` /
   `use_custom_pdf`.

## Why `proposal.sent` isn't wired into the Dispatcher yet

2.5 Contract E-Sign is triggered by its own `Proposal Accept Webhook` (the
client clicking Accept), not by anything from the Hub — that's an external
webhook entry point per the plan's own rule, so it stays as-is. Nothing else
currently needs to react to "a proposal went out." `proposal.sent` is
reported anyway, same as `lead.captured` from S3.1: harmless, falls to
`flagged_events`, and is there for traceability / future modules (e.g. a
follow-up-nudge workflow) without needing 2.4 touched again later.

## Still open / not touched in this batch

- Real workflow IDs (`REPLACE_WITH_...`) for Hub-Intake and the 2.4 target in
  Hub-Dispatcher — same placeholder convention as everywhere else.
- 2.4 doesn't have `settings.errorWorkflow` set — 1.3/1.4/1.5 have it from a
  prior (separate) audit Phase F1 batch; 2.4 was never part of that batch, so
  it's out of scope for S4.3 specifically and left untouched.
- S4.1 (2.1), S4.2 (2.3), S4.4 (2.5), S4.5 (2.6), S4.6 (2.7), S4.7 (2.8/2.9),
  S4.8 (end-to-end test) — all still open. Say the word for the next batch.

## Files in this delivery

- `growth-engine-automation/phase-2/2.4-proposal-generation/workflow.json` —
  updated (see above)
- `growth-engine-automation/phase-2/2.4-proposal-generation/README.md` —
  copied unchanged from source
- `docs/S0-EVENT-TYPE-TAXONOMY.md` — updated with the new `proposal.sent` row
  and an S4.3 status note (the plan calls this doc the "one place" that must
  stay current)

## Suggested test

Manually trigger 2.4's new entry node with a dummy
`{event_type: "lead.booked", client_id: 1, odoo_lead_id: <real test lead>,
source_module: "test", payload: {}}` — confirm it still runs the full
proposal flow end to end, and that a `proposal.sent` row lands in
`funnel_events` after `Postgres - Mark Proposal Sent`. Full S4.8 batch test
(qualified → onboarded, all hops in `funnel_events`) waits until the rest of
S4 is done.
