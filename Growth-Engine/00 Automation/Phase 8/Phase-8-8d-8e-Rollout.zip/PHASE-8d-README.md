# Phase 8d — Import + Activate (Done: Dispatcher wiring / Pending: your import steps)

Implementation Plan ke Section 6, **Phase 8d**, tasks #15–19. Is batch me do
tarah ka kaam hai — jo file-level hai wo maine kar diya (Hub-Dispatcher),
jo live-instance-level hai wo aapko karna hai (import/test/activate) — audit
kar ke exact steps neeche diye hain taaki koi guesswork na ho.

---

## 0. Audit — kya already ban chuka hai (isi session me verify kiya)

| Item | Status |
|---|---|
| `01-PHASE-8-MIGRATIONS.sql` (v2, 8a) | File ready hai, **run hui ya nahi confirm nahi** — tracker me task 1 abhi bhi ⬜ tha |
| 8.1 / 8.2 / 8.3 (campaign-aware, 8a) | Files ready, **import/activate abhi tak nahi hua** — 8b tracker rows 5–7 ⬜ |
| 8.4 / 8.5 / 8.6 (8c) | Files ready, import/activate nahi hua — ye task **15–17** |
| 8.7 Dashboard views | SQL file ready, koi import nahi chahiye (Metabase se point karna hai) |
| Hub-Dispatcher naye event branches | **✅ ab ban gaye is session me** — task 18 |
| Hub-Dispatcher activate | Aapko karna hai — task 19 |

**Important:** kyunki 8b ke rows 5–7 (8.1/8.2/8.3 import) bhi abhi tak ⬜ the,
neeche ka import order **8.1 se shuru** hota hai, sirf 8.4–8.6 se nahi — agar
8.1/8.2/8.3 pehle se import ho chuke hain to un steps ko skip kar dena.

---

## 1. Hub-Dispatcher — kya badla (`hub-dispatcher-workflow.json`)

`Switch - Route by Event Type` node me **7 naye branches** add kiye, Plan ke
Section 2 ki poori event table cover karte hue:

| event_type | Naya route | Kyun aisa |
|---|---|---|
| `contest.entry_submitted` | → `Mark Done` (seedha) | Sirf 8.7 Dashboard consume karta hai, aur wo SQL views se `funnel_events` seedha padhta hai — koi n8n workflow trigger karne ki zaroorat nahi. Pehle ye galti se "flagged" (no-route alert) ban jaata, jo false alarm hota |
| `referral.submitted` | → `Mark Done` (seedha) | wahi wajah |
| `referral.reward_earned` | → `Mark Done` (seedha) | wahi wajah |
| `community.member_joined` | → `Mark Done` (seedha) | wahi wajah |
| `audit.completed` | → **Execute Workflow - 2.1 Outreach** (naya node, existing 2.1 workflow hi reuse) | 8.3 audit requests `clients_master` me upsert karta hai, isliye `audit.completed` ka shape bilkul `lead.qualified` jaisa hai — 2.1 ka `Fetch Lead Detail` node seedha kaam karega, koi 2.1 ka code change nahi chahiye |
| `signal.lead_flagged` | → **Execute Workflow - 2.1 Outreach** (naya node, same 2.1 workflow) | ⚠️ caveat neeche Section 3 me |
| `winback.escalated` | → **Execute Workflow - 8.6 Signal Outreach** (naya node) | 6.5 Churn Win-back ye event pehle se produce karta hai (S4b se), lekin koi consumer nahi tha. 8.6 me exactly isi ke liye banaya hua entry point tha — `From Hub-Dispatcher (winback.escalated)` executeWorkflowTrigger — bas ab wired hai |

**Naye placeholders jo aapko bharne hain** (dispatcher import karte waqt):

| Placeholder | Kitni jagah | Kaunse naye node |
|---|---|---|
| `REPLACE_WITH_2.1_OUTREACH_WORKFLOW_ID` | +2 (pehle se 1 tha `lead.qualified` ke liye, ab 3 total) | Execute Workflow - 2.1 Outreach (audit.completed), (signal.lead_flagged) |
| `REPLACE_WITH_8.6_SIGNAL_OUTREACH_WORKFLOW_ID` | 1 (naya) | Execute Workflow - 8.6 Signal Outreach (winback.escalated) |

Validation: JSON valid parse hota hai, 16 switch rules ↔ 17 connection
outputs (16 + fallback) match karte hain, koi dangling connection nahi, sab
21 nodes trigger se reachable hain — checked programmatically.

---

## 2. Jo wire NAHI kiya — 2 genuine gaps, jaan-bujh kar khula chhoda

Plan ki event table 2 aur fan-outs maangti hai jo **nahi ban sakte** kyunki
receiving side pe koi entry point hi nahi hai (8c README me ye already flag
kiya gaya tha):

| event_type | Chahiye tha → | Kyun nahi bana |
|---|---|---|
| `contest.winner_selected` | 8.5 Community (winner spotlight) | 8.5 ke paas sirf webhook + schedule trigger hai, koi `executeWorkflowTrigger` nahi — Dispatcher se call karne ka rasta hi nahi hai |
| `ugc.submission_verified` | 8.2 Referral (auto referral-link generate) | 8.2 ke paas bhi sirf webhook hai, koi `executeWorkflowTrigger` nahi |

**Ye dono events ab bhi `Log Flagged Event` → Odoo Discuss alert me jaayenge,
har baar jab koi contest winner select ho ya UGC verify ho.** Ye jaan-bujh
kar hai — gap ko chhupane se better hai ki dikhta rahe jab tak fix na ho.
Fix karne ke liye 8.5 aur 8.2 me ek chhota `executeWorkflowTrigger` branch
add karna padega (8.1's winner-selection ya 8.4's manual-approval jaisa
async pattern) — scope creep hai is batch pe, bolo to alag se kar doon.

---

## 3. ⚠️ Ek aur cheez flag karni zaroori thi — `signal.lead_flagged → 2.1`

Wire to kar diya (Plan yahi maangta hai), lekin 8.6 ka apna README pehle se
flag karta hai: kai raw signals (hiring/news) ke paas seedha email/phone
nahi hota, aur 8.6 ka upsert blank-email ke saath bhi chalta hai (bas
useful `clients_master` row nahi banti). Matlab jab low-contact-info wala
signal 2.1 tak pahunchega, 2.1 ka `Fetch Lead Detail` row to dhoondh lega
(row exist karti hai), lekin WhatsApp/Email steps un blank fields pe
silently no-op/fail ho sakte hain. Crash nahi hoga, bas kuch outreach
attempts khaali jaayenge. Low-priority — agar zyada dikhe to fix wahi hai
jo 8.6 README already suggest karta hai: contact-less high-score signals
ko manual-research queue me route karo, 2.1 me mat bhejo.

---

## 4. Import order — poora sequence (agar 8.1–8.3 bhi pending hain)

**Pehle DB:**
1. `01-PHASE-8-MIGRATIONS.sql` (8a ka v2) Postgres par run karo — agar
   pehli purani migration file already run kar chuke ho, `contest_entries`/
   `referral_ledger`/`audit_requests` manually drop karke re-run karo
   (column names badle hain, 8a README Section 1 me detail hai)
2. Campaign seed data run karo (`02-CAMPAIGN-SEED-DATA.sql`, 8b/8c wali) —
   sab rows `status='draft'` hain, kuch live nahi hoga

**Phir n8n me import, is exact order me (Hub-Intake sabse pehle, jo already
ban chuka hai per Plan Section 0):**

| # | File | Placeholder(s) bharne hain |
|---|---|---|
| 1 | `8.1-Reward-Contest-Engine.json` | `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` × 2 |
| 2 | `8.2-Referral-Engine-Universal.json` | same × 3 |
| 3 | `8.3-Free-Audit-Engine.json` | same × 1 |
| 4 | `8.4-UGC-Share-Engine.json` | same × 2 |
| 5 | `8.5-Community-Engine.json` | same × 1 |
| 6 | `8.6-Signal-Based-Outreach-Engine.json` | same × 1 |
| 7 | **`hub-dispatcher-workflow.json`** (updated, is folder me) | `REPLACE_WITH_2.1_OUTREACH_WORKFLOW_ID` × 3 total, `REPLACE_WITH_8.6_SIGNAL_OUTREACH_WORKFLOW_ID` × 1 — **plus save 8.4/8.5/8.6 ke workflow IDs bhi kahin, agar future me 8.5/8.2 patch karte ho to unhi IDs chahiye honge** |

Har import ke baad workflow ko **abhi activate mat karo** — pehle sab
import ho jaayein, phir Section 5 ke test karo, tab activate karo. Dispatcher
sabse aakhir me import + activate hoga (same rule jo Phase 0–7 me thi).

---

## 5. Test karo (import ke baad, activate se pehle)

Har engine ke liye ek dummy campaign row already `draft` me hai — test ke
liye us specific row ko temporarily `active` karo, test karo, wapas
`draft` kar do (ya jo chaho):

```sql
UPDATE campaigns SET status='active' WHERE campaign_slug='nivy-top-100-2026';       -- 8.1
UPDATE campaigns SET status='active' WHERE campaign_slug='refer-and-earn-global';    -- 8.2
UPDATE campaigns SET status='active' WHERE campaign_slug='free-global-audit';        -- 8.3
UPDATE campaigns SET status='active' WHERE campaign_slug='nivy-showcase-2026';       -- 8.4
UPDATE campaigns SET status='active' WHERE campaign_slug='founders-circle-global';   -- 8.5
```

Phir har webhook test karo (apna n8n domain/port daal ke):

```bash
# 8.1 Contest
curl -X POST https://<n8n-host>/webhook/contest-entry \
  -H "Content-Type: application/json" \
  -d '{"campaign_slug":"nivy-top-100-2026","name":"Test User","email":"test@example.com"}'

# 8.2 Referral
curl -X POST https://<n8n-host>/webhook/referral-submit \
  -H "Content-Type: application/json" \
  -d '{"campaign_slug":"refer-and-earn-global","referral_code":"<existing code>","email":"test@example.com"}'

# 8.3 Free Audit
curl -X POST https://<n8n-host>/webhook/free-audit \
  -H "Content-Type: application/json" \
  -d '{"campaign_slug":"free-global-audit","url":"https://example.com","email":"test@example.com"}'

# 8.4 UGC
curl -X POST https://<n8n-host>/webhook/ugc-submit \
  -H "Content-Type: application/json" \
  -d '{"campaign_slug":"nivy-showcase-2026","email":"test@example.com","proof_url":"https://instagram.com/p/xyz"}'

# 8.5 Community
curl -X POST https://<n8n-host>/webhook/community-join \
  -H "Content-Type: application/json" \
  -d '{"campaign_slug":"founders-circle-global","email":"test@example.com","name":"Test User"}'

# 8.6 Signal (not campaign-scoped)
curl -X POST https://<n8n-host>/webhook/signal-ingest \
  -H "Content-Type: application/json" \
  -d '{"signal_type":"hiring","raw_signal":{"company":"Test Co","source":"test"}}'
```

Har call ke baad check karo `funnel_events` table me naya row bana ki nahi,
aur (Dispatcher activate hone ke baad) `status` `pending` → `dispatched` →
`done` ban raha hai ki nahi.

---

## 6. Activation order

1. 8.1, 8.2, 8.3, 8.4, 8.5, 8.6 — activate karo (koi bhi order, spoke-to-spoke
   direct link nahi hai)
2. **Sabse aakhir me** Hub-Dispatcher activate karo — is se pehle nahi,
   warna events `pending` me hi phase jaayenge (koi processing nahi hoga)

---

## 7. Progress Tracker update

| # | Task | Status | Note |
|---|---|---|---|
| 15 | 8.4 import + test + activate | ⬜ | aapka kaam — steps Section 4–6 |
| 16 | 8.5 import + test + activate | ⬜ | same |
| 17 | 8.6 import + test + activate | ⬜ | same |
| 18 | Dispatcher — baaki sab naye event IDs bharo | ✅ | branches ban gaye, **placeholders bharna baaki hai import ke waqt** |
| 19 | Dispatcher activate (sabse aakhir me) | ⬜ | aapka kaam |

**Agla step:** Section 4 ke import order follow karo, phir Phase 8e
(rollout — reward amounts/legal terms finalize, 2-3 campaigns live karna,
Implementation Plan Section 6 ke 8e tasks #20–23).
