-- ============================================================
-- Phase 8e — Monitoring queries (task #22: "2 hafte data dekho")
-- All queries run against the 8 views from
-- 02-PHASE-8c-DASHBOARD-VIEWS.sql. Point Metabase at these same
-- views for a live dashboard; these are the ad-hoc/psql version
-- for the first 2 weeks before (or instead of) Metabase is set up.
-- ============================================================

-- ------------------------------------------------------------
-- DAILY — 30-second check, run every morning during the first
-- 2 weeks. One row per active campaign.
-- ------------------------------------------------------------
SELECT campaign_slug, engine, status, total_events, unique_participants,
       starts_at, ends_at
FROM growth_campaign_performance
WHERE status = 'active'
ORDER BY total_events DESC;

-- ------------------------------------------------------------
-- WEEKLY — engine-by-engine detail, run once a week
-- ------------------------------------------------------------

-- 8.1 Contest: watch fraud_rate_pct especially — if it's
-- climbing, fraud_threshold in the contest's own config may
-- need tightening before more entries come in.
SELECT * FROM contest_performance ORDER BY total_entries DESC;

-- 8.2 Referral: conversion_rate_pct is submitted->converted/paid.
-- reward_liability_outstanding is real money you'll owe if those
-- referrals convert — watch this doesn't run ahead of budget.
SELECT * FROM referral_performance ORDER BY total_referrals DESC;

-- 8.3 Audit: later_qualified_count is the number that mattered —
-- audit requests that actually became a qualified lead in the
-- main funnel. A high total_requests with a near-zero
-- later_qualified_count means the lead magnet isn't converting.
SELECT * FROM audit_engine_performance ORDER BY total_requests DESC;

-- Cross-engine one-glance summary
SELECT * FROM growth_engine_summary;

-- ------------------------------------------------------------
-- WAVE 2 (once 8.4/8.5/8.6 go live — not needed for the first
-- 2 weeks of the initial 3-campaign launch)
-- ------------------------------------------------------------
-- SELECT * FROM ugc_engine_performance ORDER BY total_submissions DESC;
-- SELECT * FROM community_engine_performance ORDER BY total_events DESC;
-- SELECT * FROM signal_outreach_performance ORDER BY ai_score DESC;

-- ------------------------------------------------------------
-- Suggested scale/pause read (task #23) — these thresholds are
-- STARTING SUGGESTIONS ONLY, not a fixed rule. Edit to match
-- your actual budget/team-bandwidth once you see real week-1
-- numbers — there's no "right" number without your cost data.
-- ------------------------------------------------------------
-- Scale a campaign if, after 2 weeks:
--   - unique_participants is trending up week-over-week (not flat/declining)
--   - fraud_rate_pct (8.1) stays under ~15% without extra manual review load
--   - conversion_rate_pct (8.2) or later_qualified_count (8.3) shows the
--     channel is actually feeding the main sales funnel, not just vanity signups
-- Pause/rework a campaign if:
--   - total_events is flat for a full week with no growth
--   - reward_liability_outstanding (8.2) is growing faster than actual
--     paid conversions can justify
--   - manual-review load (fraud flags / UGC pending_review) is outpacing
--     what you can actually process by hand
