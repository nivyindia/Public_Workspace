-- ============================================================
-- Phase 8e — Launch the first 2-3 campaigns
-- (Implementation Plan Section 3.3 + 6, task #21)
-- Run this ONLY after every item in PHASE-8e-LAUNCH-RUNBOOK.md
-- Section 1 (Pre-Launch Checklist) is checked off.
-- ============================================================

-- ------------------------------------------------------------
-- 0. Pre-flight sanity check — run this FIRST, read the output.
--    If any row shows status != 'dispatched'/'done' pattern
--    working, or config still has placeholder-looking values,
--    STOP and fix before flipping to active.
-- ------------------------------------------------------------
SELECT campaign_slug, engine, status, starts_at, ends_at,
       config->>'name' AS campaign_name
FROM campaigns
WHERE campaign_slug IN (
  'nivy-top-100-2026',        -- 8.1 contest
  'refer-and-earn-global',    -- 8.2 referral
  'free-global-audit'         -- 8.3 free audit
)
ORDER BY engine;

-- ------------------------------------------------------------
-- 1. Recommended launch trio (per Section 3.3: 1 contest +
--    1 referral + 1 free-audit — NOT 8.4/8.5/8.6 yet, those
--    come in wave 2 per task #14/Section 6 rollout sequencing)
-- ------------------------------------------------------------

-- ⚠️ EDIT config/starts_at/ends_at FIRST if you haven't already
-- (prize amounts, dates, and legal terms in these rows are
-- still the placeholder-realistic values drafted in 8b — see
-- PHASE-8e-LAUNCH-RUNBOOK.md Section 2 for exactly what to check)

UPDATE campaigns
SET status = 'active', updated_at = now()
WHERE campaign_slug = 'nivy-top-100-2026';

UPDATE campaigns
SET status = 'active', updated_at = now()
WHERE campaign_slug = 'refer-and-earn-global';

UPDATE campaigns
SET status = 'active', updated_at = now()
WHERE campaign_slug = 'free-global-audit';

-- ------------------------------------------------------------
-- 2. Confirm
-- ------------------------------------------------------------
SELECT campaign_slug, engine, status, starts_at, ends_at
FROM campaigns
WHERE campaign_slug IN ('nivy-top-100-2026','refer-and-earn-global','free-global-audit');

-- ------------------------------------------------------------
-- 3. Rollback (if something's wrong after launch, pause fast —
--    no n8n edit needed, engines re-check campaigns.status on
--    every request)
-- ------------------------------------------------------------
-- UPDATE campaigns SET status = 'paused' WHERE campaign_slug = '<slug>';

-- ------------------------------------------------------------
-- Wave 2 (later, per task #14 — only after wave 1 has 2 weeks
-- of clean data, per task #22/#23):
-- ------------------------------------------------------------
-- UPDATE campaigns SET status = 'active', updated_at = now() WHERE campaign_slug = 'nivy-showcase-2026';       -- 8.4 UGC
-- UPDATE campaigns SET status = 'active', updated_at = now() WHERE campaign_slug = 'founders-circle-global';   -- 8.5 Community
-- (8.6 Signal-Based Outreach is not campaign_id-scoped — it runs continuously once its workflow is activated, no campaigns-table flip needed)
