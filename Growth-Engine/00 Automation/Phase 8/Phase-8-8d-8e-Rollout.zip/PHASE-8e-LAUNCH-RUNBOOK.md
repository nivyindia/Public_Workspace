# Phase 8e — Rollout (Launch Runbook)

Implementation Plan ke Section 6, **Phase 8e**, tasks #20–23. Ye pura phase
mostly business-side decisions hai (Section 8 ki table ke hisab se: reward
amounts, contest copy, legal terms, "kaunsa campaign pehle" — sab ❌ Aap).
Jo main de sakta hoon: audit karke exact blockers ki list, launch-day
checklist, activation script, aur monitoring queries — taaki jab number
plug karo to bas launch karna baaki rahe.

---

## 1. Pre-Launch Checklist — launch se PEHLE ye sab ✅ hona chahiye

Audit kiya poore Phase 8 build ka — ye har cheez hai jo abhi tak kisi na
kisi phase me "aapka kaam" flag hui thi aur launch se pehle chahiye:

| # | Item | Kahan se aata hai | Status |
|---|---|---|---|
| 1 | `01-PHASE-8-MIGRATIONS.sql` (v2) run | 8a | ⬜ aapka kaam |
| 2 | 8.1/8.2/8.3/8.4/8.5/8.6 import + activate n8n me | 8a–8d | ⬜ aapka kaam (guide: `PHASE-8d-README.md`) |
| 3 | Hub-Dispatcher import + activate (naye branches ke saath) | 8d | ⬜ aapka kaam |
| 4 | WhatsApp/Telegram/Email NoOp nodes → real credentials | 8a/8c | ⬜ aapka kaam (8 placeholders total across 8.1–8.6) |
| 5 | Firecrawl + PageSpeed API keys (8.3 audit engine) | 8a | ⬜ aapka kaam |
| 6 | Landing page `WEBHOOK_URL` placeholders bharo | 8b/8c-supporting | ⬜ **6 files** — list neeche Section 3 |
| 7 | Prize amounts / reward amounts / dates — placeholder se real | 8b | ⬜ **abhi bhi placeholder hai**, list neeche Section 2 |
| 8 | Legal review — contest rules, T&C, per-country notes | 8b | ⬜ **koi bhi market live karne se pehle lawyer se confirm** |
| 9 | `campaigns` table rows ko `active` karo | 8b/8c seed data | ⬜ script ready: `03-ACTIVATE-LAUNCH-CAMPAIGNS.sql` |
| 10 | 2 flagged spoke→spoke gaps ka decision | 8c/8d | ⬜ launch ko block nahi karta, per Section 4 neeche |

---

## 2. ⚠️ Reward amounts/copy — abhi bhi placeholder hai (audit confirm)

`8b/02-CAMPAIGN-SEED-DATA.sql` file khud kehti hai: *"All prize amounts,
dates, and copy are PLACEHOLDER / EXAMPLE values... edit freely before
setting status = 'active'."* Maine check kiya, ye abhi bhi waisa hi hai —
koi edit nahi hui is session tak. Launch se pehle in teeno campaigns ka
config JSONB edit karna hoga:

| Campaign | File jahan config hai | Kya edit karna hai |
|---|---|---|
| `nivy-top-100-2026` (8.1) | `02-CAMPAIGN-SEED-DATA.sql` (8b) | prize components, ARV, categories, eligible countries, dates |
| `refer-and-earn-global` (8.2) | same | reward tiers (stage1_flat/stage2_pct), payout window |
| `free-global-audit` (8.3) | same | koi monetary reward nahi, bas dates/copy check karo |

Edit karne ka tarika: seed-data file me values badlo, phir
`03-ACTIVATE-LAUNCH-CAMPAIGNS.sql` chalane se pehle ek
`UPDATE campaigns SET config = '...'::jsonb WHERE campaign_slug = '...'`
se DB me bhi update karo (agar seed data already run ho chuki hai) — sirf
file edit karna kaafi nahi hai, DB row alag se update honi padegi.

---

## 3. Landing pages — 6 `WEBHOOK_URL` placeholders

| File | Placeholder | Kis webhook se point karna hai |
|---|---|---|
| `04-landing-page-contest-entry.html` | `REPLACE_WITH_8-1_WEBHOOK_URL` | 8.1's `/contest-entry` |
| `02-landing-page-referral.html` | `REPLACE_WITH_8-2_WEBHOOK_URL` | 8.2's `/referral-submit` |
| `02-landing-page-free-audit.html` | `REPLACE_WITH_8-3_WEBHOOK_URL` | 8.3's `/free-audit` |
| `02-landing-page-showcase.html` | `REPLACE_WITH_8-4_WEBHOOK_URL` | 8.4's `/ugc-submit` |
| `02-landing-page-founders-circle.html` | `REPLACE_WITH_8-5_WEBHOOK_URL` | 8.5's `/community-join` |
| `02-opt-out-confirmation-page.html` | `REPLACE_WITH_OPTOUT_FEEDBACK_WEBHOOK_URL` | opt-out feedback capture endpoint (aapko decide karna hai ye kahan jaata hai — abhi koi spoke nahi isko explicitly consume karta) |

Sab n8n activate hone ke baad hi actual webhook URLs milenge (n8n
instance domain + webhook path). 8.6 ka koi landing page nahi hai —
sirf internal signal-ingest hai, end-user-facing nahi.

---

## 4. Legal — genuinely aapka kaam, main draft nahi kar sakta

`03-Country-Specific-Legal-Notes.md` (8b) already 6 markets (US/UK/CA/AU/
AE/IN) ke gotchas list karta hai — highlights:
- **US**: NY/FL/RI me $5,000+ prizes ke liye bonding/state registration
- **Canada**: Quebec ko exclude karne ka suggestion hai jab tak volume na ho
- **UAE**: trade promotion permit chahiye ho sakta hai, local counsel review recommended
- Doc khud recommend karta hai: **skill/merit-judged contest (Top 100 Awards) pehle launch karo** — sabse kam risk, chance-element wale mechanics baad me

Ye sab already draft ho chuka hai T&C/rules docs me, lekin **koi bhi market
live karne se pehle ek baar real lawyer se confirm karwana** — main legal
advice nahi de sakta, sirf flag kar sakta hoon.

---

## 5. Do flagged gaps — launch block NAHI karte, but track karo

Phase 8d me flag kiya tha: `contest.winner_selected → 8.5` aur
`ugc.submission_verified → 8.2` — dono unbuilt hain (receiving spoke me
entry point nahi hai). Launch ke liye ye **blocking nahi hai** kyunki:
- Contest launch ho sakta hai bina winner-spotlight-in-community automation ke — winner selection khud (8.1's manual trigger) kaam karta hai, bas community post manually karni padegi jab tak patch na ho
- UGC (8.4) wave-2 me aa raha hai (Section 6 neeche), tab tak isko patch karne ka time hai

Agar chahte ho to launch se pehle bhi patch kara sakte ho — bolo.

---

## 6. Rollout sequencing (tasks #21–23)

**Wave 1 — abhi (task #21):** `03-ACTIVATE-LAUNCH-CAMPAIGNS.sql` chalao,
sirf teen: `nivy-top-100-2026` (contest) + `refer-and-earn-global`
(referral) + `free-global-audit` (audit). Section 3.3 ka wahi reasoning —
team/budget manage hota hai, data clean milta hai.

**2 hafte monitor karo (task #22):** `04-WEEKLY-MONITORING-QUERIES.sql` —
daily 30-second check + weekly per-engine detail. Agar Metabase live hai,
same 8 views wahan point kar do, in queries ki zaroorat nahi rahegi.

**Decide (task #23):** file ke end me starter scale/pause heuristics diye
hain — **ye suggestions hain, final call budget/bandwidth pe depend karta
hai jo sirf aap jaante ho.**

**Wave 2 (task #14, baad me):** `03-ACTIVATE-LAUNCH-CAMPAIGNS.sql` ke
end me commented-out UPDATEs hain `nivy-showcase-2026` (8.4) aur
`founders-circle-global` (8.5) ke liye — jab wave 1 stable dikhe tab
uncomment karke chalao. 8.6 (signal-based outreach) `campaigns` table se
scoped nahi hai — uska workflow activate hote hi continuously chalta hai,
koi separate flip nahi chahiye.

---

## 7. Progress Tracker update

| # | Task | Status | Note |
|---|---|---|---|
| 20 | Reward amounts / contest copy / legal terms finalize | ⬜ | aapka kaam — exact list Section 2 aur 4 |
| 21 | Pehle 2-3 campaigns ke rows `active` | ⬜ | script ready, run after Section 1 checklist |
| 22 | 2 hafte data monitor | ⬜ | queries ready |
| 23 | Scale/pause decide | ⬜ | starter heuristics diye hain, final call aapka |

Poora Phase 8 (8a → 8e) ab file-level complete hai. Baaki sab jo bacha hai
Section 1 ki checklist hai — wahi asli "agla step" hai.
