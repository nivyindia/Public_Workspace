# Phase 8 — Blockers & Data-Quality Flags (Consolidated)

Poore Phase 8 build (8a se 8e tak) me jo bhi flag hua tha, sab ek jagah —
taaki launch se pehle line-by-line check kar sako. Har row ka apna
priority hai: **🔴 Launch-blocking**, **🟡 Should-fix-soon**, **⚪ Track-only
(launch block nahi karta)**.

---

## 🔴 Launch-blocking

| # | Blocker | Kahan | Kya chahiye | Kaun karega |
|---|---|---|---|---|
| 1 | `01-PHASE-8-MIGRATIONS.sql` (v2) run hui ya nahi — **unconfirmed** | 8a | Postgres par run karo, confirm karo | Aap |
| 2 | 8.1/8.2/8.3 n8n me import/activate — **unconfirmed** | 8a/8b | Import karo (guide: `PHASE-8d-README.md` Section 4) | Aap |
| 3 | 8.4/8.5/8.6 n8n me import/activate | 8c/8d | Same guide | Aap |
| 4 | Hub-Dispatcher import/activate (updated file, naye branches) | 8d | Sabse aakhir me, dono placeholder IDs bhar ke | Aap |
| 5 | Reward/prize amounts abhi bhi placeholder (`nivy-top-100-2026`, `refer-and-earn-global`) | 8b seed data | Real numbers finalize karo, DB row update karo | Aap (business decision) |
| 6 | Legal review — koi bhi market live karne se pehle | 8b legal docs | Lawyer se `01-Terms-and-Conditions.md` + per-country notes confirm karwao | Aap |
| 7 | 6 landing pages me `WEBHOOK_URL` placeholder | 8b/8c-supporting | n8n activate hone ke baad actual URLs bharo (list: `PHASE-8e-LAUNCH-RUNBOOK.md` Section 3) | Aap |

---

## 🟡 Should-fix-soon (launch block nahi karta, but jaldi karna chahiye)

| # | Blocker | Kahan | Kya chahiye | Kaun karega |
|---|---|---|---|---|
| 8 | WhatsApp/Telegram/Email — 8 NoOp placeholder nodes real credentials se wire karna (8.1–8.6 sab me) | 8a/8c | Apne real accounts se connect karo | Aap |
| 9 | Firecrawl + PageSpeed API keys (8.3 audit engine) | 8a | Keys generate/daalo | Aap |
| 10 | `signal.lead_flagged → 2.1` — kuch signals blank email/phone ke saath aa sakte hain, 2.1 me silently no-op ho jaayenge | 8d | Low-priority fix: contact-less signals ko manual-research queue me route karo (2.1 me mat bhejo) | Main (agar bologe) |

---

## ⚪ Track-only (structural gaps, launch block nahi karte)

| # | Gap | Kahan | Kyun nahi bana | Kaun karega |
|---|---|---|---|---|
| 11 | `contest.winner_selected → 8.5` (winner spotlight in community) | 8c/8d | 8.5 ke paas koi `executeWorkflowTrigger` entry point nahi | Main (patch chahiye 8.5 me) |
| 12 | `ugc.submission_verified → 8.2` (auto referral-link for UGC submitters) | 8c/8d | 8.2 ke paas bhi koi entry point nahi | Main (patch chahiye 8.2 me) |
| 13 | `client.onboarded`, `renewal.due`, `renewal.overdue`, `payment.failed` — pre-existing, Phase 8 se pehle se unconsumed | v6 (S4b) | Koi downstream module hi nahi bana abhi tak (Phase 6 churn/renewal work) | Aap decide karo priority |
| 14 | Opt-out feedback webhook (`REPLACE_WITH_OPTOUT_FEEDBACK_WEBHOOK_URL`) kis endpoint pe jaana chahiye — koi spoke isko abhi consume nahi karta | 8c-supporting | Decide karo destination, phir wire karo | Aap |

---

## Snapshot

| Priority | Count | Sab aapka kaam hai, ya main bhi kar sakta hoon? |
|---|---|---|
| 🔴 Launch-blocking | 7 | 6 aapka (import/credentials/legal/money), 1 shared (webhook fill-in depends on aapke import ke baad) |
| 🟡 Should-fix-soon | 3 | 2 aapka (credentials/keys), 1 main kar sakta hoon agar bolo |
| ⚪ Track-only | 4 | 2 main patch kar sakta hoon (8.5/8.2 entry points), 2 aapka decision |

**Sabse zyada leverage wala agla step:** items #1–4 (migration + import +
activate) — jab tak ye na ho, koi aur item test bhi nahi ho sakta.
